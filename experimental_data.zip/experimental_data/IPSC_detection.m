clear
clc
close all 
addpath experimental_data

figure_10Hz=0;
figure_20Hz=1;
figure_130Hz=0;
%%
[D si]=abfload('SD_GA_10Hz_23.11.15_2_ch3.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear IPSC_10_ch3
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        IPSC_10_ch3(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     IPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    IPSC_10_ch3=IPSC_10_ch3(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(IPSC_10_ch3),'k')
    [peak_IPSC_10_ch3(:,j),peak_locs]=max(IPSC_10_ch3);
    if figure_10Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        title('10Hz-ch3')
        plot((locs+[25:400]-1)',IPSC_10_ch3,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_10_ch3(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',IPSC_10_ch3,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_10_ch3(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1.1e4 2e4])
    end
end
figure(100); hold on
title('10Hz-ch3')
p(1)=plot(mean(peak_IPSC_10_ch3')/mean(peak_IPSC_10_ch3(1,:)),'b','LineWidth',2);
plot((mean(peak_IPSC_10_ch3')-std(peak_IPSC_10_ch3'))/mean(peak_IPSC_10_ch3(1,:)),'--b','LineWidth',1)
plot((mean(peak_IPSC_10_ch3')+std(peak_IPSC_10_ch3'))/mean(peak_IPSC_10_ch3(1,:)),'--b','LineWidth',1)


%%
[D si]=abfload('SD_GA_10Hz_23.11.15_2_ch7.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear IPSC_10_ch7
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        IPSC_10_ch7(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     IPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    IPSC_10_ch7=IPSC_10_ch7(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(IPSC_10_ch7),'k')
    [peak_IPSC_10_ch7(:,j),peak_locs]=max(IPSC_10_ch7);
    if figure_10Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20);
        title('10Hz-ch7')
        plot((locs+[25:400]-1)',IPSC_10_ch7,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_10_ch7(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',IPSC_10_ch7,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_10_ch7(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1.1e4 2e4])
    end
end
figure(100); hold on
title('10Hz')
p(2)=plot(mean(peak_IPSC_10_ch7')/mean(peak_IPSC_10_ch7(1,:)),'r','LineWidth',2);
plot((mean(peak_IPSC_10_ch7')-std(peak_IPSC_10_ch7'))/mean(peak_IPSC_10_ch7(1,:)),'--r','LineWidth',1)
plot((mean(peak_IPSC_10_ch7')+std(peak_IPSC_10_ch7'))/mean(peak_IPSC_10_ch7(1,:)),'--r','LineWidth',1)

legend(p,{'ch3','ch7'})

%% for 20Hz stimulation


[D si]=abfload('SD_GA_20Hz_23.11.15_2_ch3.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear IPSC_20_ch3
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        IPSC_20_ch3(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     IPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    IPSC_20_ch3=IPSC_20_ch3(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(IPSC_20_ch3),'k')
    [peak_IPSC_20_ch3(:,j),peak_locs]=max(IPSC_20_ch3);
    if figure_20Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        title('20Hz-ch3')
        plot((locs+[25:400]-1)',IPSC_20_ch3,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_20_ch3(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',IPSC_20_ch3,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_20_ch3(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1.1e4 2e4])
    end
end
figure(101); hold on
title('20Hz-ch3')
p(1)=plot(mean(peak_IPSC_20_ch3')/mean(peak_IPSC_20_ch3(1,:)),'b','LineWidth',2);
plot((mean(peak_IPSC_20_ch3')-std(peak_IPSC_20_ch3'))/mean(peak_IPSC_20_ch3(1,:)),'--b','LineWidth',1)
plot((mean(peak_IPSC_20_ch3')+std(peak_IPSC_20_ch3'))/mean(peak_IPSC_20_ch3(1,:)),'--b','LineWidth',1)


%%
[D si]=abfload('SD_GA_20Hz_23.11.15_2_ch7.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear IPSC_20_ch7
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        IPSC_20_ch7(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     IPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    IPSC_20_ch7=IPSC_20_ch7(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(IPSC_20_ch7),'k')
    [peak_IPSC_20_ch7(:,j),peak_locs]=max(IPSC_20_ch7);
    if figure_20Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20);
        title('20Hz-ch7')
        plot((locs+[25:400]-1)',IPSC_20_ch7,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_20_ch7(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',IPSC_20_ch7,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_20_ch7(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1.1e4 2e4])
    end
end
figure(101); hold on
title('20Hz')
p(2)=plot(mean(peak_IPSC_20_ch7')/mean(peak_IPSC_20_ch7(1,:)),'r','LineWidth',2);
plot((mean(peak_IPSC_20_ch7')-std(peak_IPSC_20_ch7'))/mean(peak_IPSC_20_ch7(1,:)),'--r','LineWidth',1)
plot((mean(peak_IPSC_20_ch7')+std(peak_IPSC_20_ch7'))/mean(peak_IPSC_20_ch7(1,:)),'--r','LineWidth',1)

legend(p,{'ch3','ch7'})

%% for 130Hz stimulation


[D si]=abfload('SD_GA_130Hz_23.11.15_2_ch3.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear IPSC_130_ch3
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',100);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        IPSC_130_ch3(:,i)=Postsynaptic_current(locs(i):locs(i)+150);
    end
%     IPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    IPSC_130_ch3=IPSC_130_ch3(25:150,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(IPSC_130_ch3),'k')
    [peak_IPSC_130_ch3(:,j),peak_locs]=max(IPSC_130_ch3);
    if figure_130Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        title('130Hz-ch3')
        plot((locs+[25:150]-1)',IPSC_130_ch3,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_130_ch3(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:150]-1)',IPSC_130_ch3,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_130_ch3(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1.1e4 2.2e4])
    end
end
figure(103); hold on
title('130Hz-ch3')
p(1)=plot(mean(peak_IPSC_130_ch3')/mean(peak_IPSC_130_ch3(1,:)),'b','LineWidth',2);
plot((mean(peak_IPSC_130_ch3')-std(peak_IPSC_130_ch3'))/mean(peak_IPSC_130_ch3(1,:)),'--b','LineWidth',1)
plot((mean(peak_IPSC_130_ch3')+std(peak_IPSC_130_ch3'))/mean(peak_IPSC_130_ch3(1,:)),'--b','LineWidth',1)


%%
[D si]=abfload('SD_GA_130Hz_23.11.15_2_ch7.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear IPSC_130_ch7
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',150);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        IPSC_130_ch7(:,i)=Postsynaptic_current(locs(i):locs(i)+150);
    end
%     IPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    IPSC_130_ch7=IPSC_130_ch7(25:150,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(IPSC_130_ch7),'k')
    [peak_IPSC_130_ch7(:,j),peak_locs]=max(IPSC_130_ch7);
    if figure_130Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20);
        title('130Hz-ch7')
        plot((locs+[25:150]-1)',IPSC_130_ch7,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_130_ch7(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:150]-1)',IPSC_130_ch7,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_IPSC_130_ch7(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1.1e4 2.2e4])
    end
end
figure(103); hold on
title('130Hz')
p(2)=plot(mean(peak_IPSC_130_ch7')/mean(peak_IPSC_130_ch7(1,:)),'r','LineWidth',2);
plot((mean(peak_IPSC_130_ch7')-std(peak_IPSC_130_ch7'))/mean(peak_IPSC_130_ch7(1,:)),'--r','LineWidth',1)
plot((mean(peak_IPSC_130_ch7')+std(peak_IPSC_130_ch7'))/mean(peak_IPSC_130_ch7(1,:)),'--r','LineWidth',1)

legend(p,{'ch3','ch7'})

