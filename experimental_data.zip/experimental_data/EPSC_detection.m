clear
clc
close all 
addpath experimental_data

figure_10Hz=0;
figure_20Hz=0;
figure_130Hz=0;
%%
[D si]=abfload('SD_GL_10Hz_23.11.15_2_ch4.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=-(x-median(x));
for j=1:10
    clear EPSC_10_ch4
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        EPSC_10_ch4(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     EPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    EPSC_10_ch4=EPSC_10_ch4(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(EPSC_10_ch4),'k')
    [peak_EPSC_10_ch4(:,j),peak_locs]=max(EPSC_10_ch4);
    if figure_10Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        title('10Hz-ch4')
        plot((locs+[25:400]-1)',EPSC_10_ch4,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_10_ch4(:,j),'.k','MarkerSize',10)
        ylim([-300 300])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',EPSC_10_ch4,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_10_ch4(:,j),'.k','MarkerSize',10)
        ylim([-300 300])
        xlim([1.1e4 2.2e4])
    end
end
figure(100); hold on
title('10Hz-ch4')
p(1)=plot(mean(peak_EPSC_10_ch4')/mean(peak_EPSC_10_ch4(1,:)),'b','LineWidth',2);
plot((mean(peak_EPSC_10_ch4')-std(peak_EPSC_10_ch4'))/mean(peak_EPSC_10_ch4(1,:)),'--b','LineWidth',1)
plot((mean(peak_EPSC_10_ch4')+std(peak_EPSC_10_ch4'))/mean(peak_EPSC_10_ch4(1,:)),'--b','LineWidth',1)


%%
[D si]=abfload('SD_GL_10Hz_23.11.15_2_ch6.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=-(x-median(x));
for j=1:10
    clear EPSC_10_ch6
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        EPSC_10_ch6(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     EPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    EPSC_10_ch6=EPSC_10_ch6(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(EPSC_10_ch6),'k')
    [peak_EPSC_10_ch6(:,j),peak_locs]=max(EPSC_10_ch6);
    if figure_10Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20);
        title('10Hz-ch6')
        plot((locs+[25:400]-1)',EPSC_10_ch6,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_10_ch6(:,j),'.k','MarkerSize',10)
        ylim([-300 300])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',EPSC_10_ch6,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_10_ch6(:,j),'.k','MarkerSize',10)
        ylim([-300 300])
        xlim([1.1e4 2e4])
    end
end
figure(100); hold on
title('10Hz')
p(2)=plot(mean(peak_EPSC_10_ch6')/mean(peak_EPSC_10_ch6(1,:)),'r','LineWidth',2);
plot((mean(peak_EPSC_10_ch6')-std(peak_EPSC_10_ch6'))/mean(peak_EPSC_10_ch6(1,:)),'--r','LineWidth',1)
plot((mean(peak_EPSC_10_ch6')+std(peak_EPSC_10_ch6'))/mean(peak_EPSC_10_ch6(1,:)),'--r','LineWidth',1)

legend(p,{'ch4','ch6'})

%% for 20Hz stimulation


[D si]=abfload('SD_GL_20Hz_23.11.15_2_ch4.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear EPSC_20_ch4
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        EPSC_20_ch4(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     EPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    EPSC_20_ch4=EPSC_20_ch4(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(EPSC_20_ch4),'k')
    [peak_EPSC_20_ch4(:,j),peak_locs]=max(EPSC_20_ch4);
    if figure_20Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        title('20Hz-ch4')
        plot((locs+[25:400]-1)',EPSC_20_ch4,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_20_ch4(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',EPSC_20_ch4,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_20_ch4(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1.1e4 2.2e4])
    end
end
figure(101); hold on
title('20Hz-ch4')
p(1)=plot(mean(peak_EPSC_20_ch4')/mean(peak_EPSC_20_ch4(1,:)),'b','LineWidth',2);
plot((mean(peak_EPSC_20_ch4')-std(peak_EPSC_20_ch4'))/mean(peak_EPSC_20_ch4(1,:)),'--b','LineWidth',1)
plot((mean(peak_EPSC_20_ch4')+std(peak_EPSC_20_ch4'))/mean(peak_EPSC_20_ch4(1,:)),'--b','LineWidth',1)


%%
[D si]=abfload('SD_GL_20Hz_23.11.15_2_ch4.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=-(x-median(x));
for j=1:10
    clear EPSC_20_ch6
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',900);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        EPSC_20_ch6(:,i)=Postsynaptic_current(locs(i):locs(i)+500);
    end
%     EPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    EPSC_20_ch6=EPSC_20_ch6(25:400,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(EPSC_20_ch6),'k')
    [peak_EPSC_20_ch6(:,j),peak_locs]=max(EPSC_20_ch6);
    if figure_20Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20);
        title('20Hz-ch6')
        plot((locs+[25:400]-1)',EPSC_20_ch6,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_20_ch6(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:400]-1)',EPSC_20_ch6,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_20_ch6(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1.1e4 2e4])
    end
end
figure(101); hold on
title('20Hz')
p(2)=plot(mean(peak_EPSC_20_ch6')/mean(peak_EPSC_20_ch6(1,:)),'r','LineWidth',2);
plot((mean(peak_EPSC_20_ch6')-std(peak_EPSC_20_ch6'))/mean(peak_EPSC_20_ch6(1,:)),'--r','LineWidth',1)
plot((mean(peak_EPSC_20_ch6')+std(peak_EPSC_20_ch6'))/mean(peak_EPSC_20_ch6(1,:)),'--r','LineWidth',1)

legend(p,{'ch4','ch6'})

%% for 130Hz stimulation


[D si]=abfload('SD_GL_130Hz_23.11.15_2_ch4.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear EPSC_130_ch4
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',250,'MinPeakDistance',100);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        EPSC_130_ch4(:,i)=Postsynaptic_current(locs(i):locs(i)+150);
    end
%     EPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    EPSC_130_ch4=EPSC_130_ch4(25:100,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(EPSC_130_ch4),'k')
    [peak_EPSC_130_ch4(:,j),peak_locs]=max(EPSC_130_ch4);
    if figure_130Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        title('130Hz-ch4')
        plot((locs+[25:100]-1)',EPSC_130_ch4,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_130_ch4(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:100]-1)',EPSC_130_ch4,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_130_ch4(:,j),'.k','MarkerSize',10)
        ylim([-50 500])
        xlim([1.1e4 2.2e4])
    end
end
figure(103); hold on
title('130Hz-ch4')
p(1)=plot(mean(peak_EPSC_130_ch4')/mean(peak_EPSC_130_ch4(1,:)),'b','LineWidth',2);
plot((mean(peak_EPSC_130_ch4')-std(peak_EPSC_130_ch4'))/mean(peak_EPSC_130_ch4(1,:)),'--b','LineWidth',1)
plot((mean(peak_EPSC_130_ch4')+std(peak_EPSC_130_ch4'))/mean(peak_EPSC_130_ch4(1,:)),'--b','LineWidth',1)


%%
[D si]=abfload('SD_GL_130Hz_23.11.15_2_ch6.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
for j=1:10
    clear EPSC_130_ch6
    Postsynaptic_current=x(4e4:6.5e4,j);
    [vals, locs]=findpeaks(Postsynaptic_current,'MinPeakHeight',150,'MinPeakDistance',150);
%     figure; plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
    
    for i=1:length(locs)
        EPSC_130_ch6(:,i)=Postsynaptic_current(locs(i):locs(i)+150);
    end
%     EPSC(:,length(locs))=Postsynaptic_current(locs(i+1):locs(i+1)+1000);

    EPSC_130_ch6=EPSC_130_ch6(25:100,:);
    
%     figure
%     plot(y)
    
%     hold on
%     plot(max(EPSC_130_ch6),'k')
    [peak_EPSC_130_ch6(:,j),peak_locs]=max(EPSC_130_ch6);
    if figure_130Hz==1
        figure('Position',[100 100 900 400]); 
        subplot(2,1,1); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20);
        title('130Hz-ch6')
        plot((locs+[25:100]-1)',EPSC_130_ch6,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_130_ch6(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1000 1e4])

        subplot(2,1,2); plot(Postsynaptic_current); hold on; plot(locs,vals,'.','MarkerSize',20)
        plot((locs+[25:100]-1)',EPSC_130_ch6,'r','LineWidth',1)
        plot(locs+peak_locs'+25-2, peak_EPSC_130_ch6(:,j),'.k','MarkerSize',10)
        ylim([-200 200])
        xlim([1.1e4 2.2e4])
    end
end
figure(103); hold on
title('130Hz')
p(2)=plot(mean(peak_EPSC_130_ch6')/mean(peak_EPSC_130_ch6(1,:)),'r','LineWidth',2);
plot((mean(peak_EPSC_130_ch6')-std(peak_EPSC_130_ch6'))/mean(peak_EPSC_130_ch6(1,:)),'--r','LineWidth',1)
plot((mean(peak_EPSC_130_ch6')+std(peak_EPSC_130_ch6'))/mean(peak_EPSC_130_ch6(1,:)),'--r','LineWidth',1)

legend(p,{'ch4','ch6'})

