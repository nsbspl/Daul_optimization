%% proof of principal of the accuracy of the steady-state analytical solution
% clear 
% close all 
%% 
ModelColor='r';
DataColor='k';
fs=2e4;
%%
figure(130); hold off
[D si]=abfload('SD_GA_130Hz_23.11.15_2_ch3.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
S=41435;
E=62000;
s=subplot(2,1,1);
set(s,'box','off');
plot( (1:E-S+1)/fs,mean(x(S:E,trials),2)/400,DataColor);hold on
ylim([-.1 1.5])
xlim([0 .5])
s=subplot(2,1,2);
set(s,'box','off');
plot( (1:E-S+1)/fs,mean(x(S:E,trials),2)/400,DataColor);hold on
ylim([-.1 1.5])
xlim([.5 1])
IPSP130=mean(x(S:E,trials),2)/400;
%%
figure(20); hold off
[D si]=abfload('SD_GA_20Hz_23.11.15_2_ch3.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
S=40580;
E=62000;
s=subplot(2,1,1);
set(s,'box','off');
plot( (1:E-S+1)/fs,mean(x(S:E,trials),2)/400,DataColor);hold on
ylim([-.1 1.5])
xlim([0.02 .53])
s=subplot(2,1,2);
set(s,'box','off');
plot( (1:E-S+1)/fs,mean(x(S:E,trials),2)/400,DataColor);hold on
ylim([-.1 1.5])
xlim([.52 1.03])
IPSP20=mean(x(S:E,trials),2)/400;
%%
figure(10); hold off
S=39590;
E=62000;
[D si]=abfload('SD_GA_10Hz_23.11.15_2_ch3.abf');
[h w d]=size(D);
x=reshape(D,[h d]);
x=x-median(x);
s=subplot(2,1,1);
set(s,'box','off');
plot( (1:E-S+1)/fs,mean(x(S:E,trials),2)/400,DataColor);hold on
ylim([-.1 1.5])
xlim([0.02 .53])
s=subplot(2,1,2);
set(s,'box','off');
plot( (1:E-S+1)/fs,mean(x(S:E,trials),2)/400,DataColor);hold on
ylim([-.1 1.5])
xlim([0.52 1.03])
IPSP10=mean(x(S:E,trials),2)/400;
%%

f=mean(exp(f__(end-10:end)))
U=mean(U__(end-10:end))
F=mean(F__(end-10:end))
D=mean(D__(end-10:end))
% T_syn=.0025;
T_rise=.2/1000;


F_DBS_sparse=[10,20,130];
n=0;
for i=F_DBS_sparse(1:end)
    n=n+1;
    figure(i);
    s=subplot(2,1,1); set(s,'box','off','Visible','off');
    I=zeros(1,floor(i*10000/i)+1);
    I(floor(10000*(1:i)./i))=DBS_profile_neurotransmitters(f,U,F,D,0,i,i);
%     IPSC_profile=exp(-1*(0:5000)./(T_syn*1e4));
    IPSC_profile=(1-exp(-1*(0:5000)./(T_rise*fs))).*exp(-1*(0:5000)./(T_syn*fs));
    IPSC_profile=IPSC_profile/max(IPSC_profile);
    I=conv(I,IPSC_profile)/(U+f*(1-U));
    p(2)=plot((1:length(I))/floor(10000./1),I,'Color',ModelColor,'LineWidth',1.5); hold on
%     xlim([0.05 .55])
    ylim([-.1 1.2])
    title(['F_{DBS}=',num2str(i),'Hz'])
    
    s=subplot(2,1,2); set(s,'box','off','Visible','off');
    I=zeros(1,floor(i*10000/i)+1);
    I(floor(10000*(1:i)./i))=DBS_profile_neurotransmitters(f,U,F,D,0,i,i);
%     IPSC_profile=exp(-1*(0:5000)./(T_syn*1e4));
    IPSC_profile=(1-exp(-1*(0:5000)./(T_rise*fs))).*exp(-1*(0:5000)./(T_syn*fs));
    IPSC_profile=IPSC_profile/max(IPSC_profile);
    I=conv(I,IPSC_profile)/(U+f*(1-U));
    
    p(2)=plot((1:length(I))/floor(10000./1),I,'Color',ModelColor,'LineWidth',1.5); hold on
%     xlim([.55 1.05])
    ylim([-.1 1.2])
    switch i
        case 10
            I10=resample(I,2,1);
            Res10=smooth(I10(1:length(IPSP10))-IPSP10',10);
        case 20
            I20=resample(I,2,1);
            Res20=smooth(I20(1:length(IPSP20))-IPSP20',10);
        case 130
            I130=resample(I,2,1);
            Res130=smooth(I130(1:length(IPSP130))-IPSP130',10);
    end
    
end
figure; title('10Hz Residual')
hold on
plot(IPSP10,'k')
plot(I10,'b')
plot(smooth(I10(1:length(IPSP10))-IPSP10',10),'r','LineWidth',1.5)
% ylim([-1 1.5])
% xlim([0 .02])

figure; title('20Hz Residual')
hold on
plot(IPSP20,'k')
plot(I20,'b')
plot(smooth(I20(1:length(IPSP20))-IPSP20',10),'r','LineWidth',1.5)
ylim([-1 1.5])

figure; title('130Hz Residual')
hold on
plot(IPSP130,'k')
plot(I130,'b')
plot(smooth(I130(1:length(IPSP130))-IPSP130',10),'r','LineWidth',1.5)
ylim([-1 1.5])


%%
[hs,pks10]=findpeaks(IPSP10,'MinPeakHeight',1.5);
EPSC10_locs=pks10+(21:520);
for i=1:10
    EPSC10(i)=sum(Res10(EPSC10_locs(i,:)));
end

[hs,pks20]=findpeaks(IPSP20,'MinPeakHeight',1.5);
EPSC20_locs=pks20+(21:520);
for i=1:20
    EPSC20(i)=sum(Res20(EPSC20_locs(i,:)));
end

[hs,pks130]=findpeaks(IPSP130,'MinPeakHeight',1.5);
EPSC130_locs=pks130+(21:520);
for i=1:size(EPSC130_locs,1)
    EPSC130(i)=sum(Res130(EPSC130_locs(i,:)));
end

figure; 
hold on
plot(pks10-pks10(1),EPSC10)
plot(pks20-pks20(1),EPSC20)
plot(pks130-pks130(1),EPSC130)
legend('10','20','130')


figure; 
hold on
plot(pks10-pks10(1),EPSC10/EPSC10(1))
plot(pks20-pks20(1),EPSC20/EPSC20(1))
plot(pks130-pks130(1),EPSC130/EPSC130(1))
legend('10','20','130')
