function [fitresult, gof] = gradient_fit_experimental_4params(F_DBS_, I_inf,x0, ub, lb,T_syn)
f0=x0(1);
U0=x0(2);
D0=x0(3);
F0=x0(4);
%% Fit: 'close_form_sol'.
[xData, yData] = prepareCurveData( F_DBS_, I_inf );

% Set up fittype and options.
ft = fittype( ['((((U*(1-exp(-1./(x*F)))+exp(f)*exp(-1./(x*F)))/(1-(1-exp(f))*exp(-1./(x*F))))*(1-exp(f))+exp(f))*((1-exp(-1./(x*D)))/(1-(1-((U*(1-exp(-1./(x*F)))+exp(f)*exp(-1./(x*F)))/(1-(1-exp(f))*exp(-1./(x*F)))))*exp(-1./(x*D)))))/((1-exp(-1./(x*',num2str(T_syn),')))*(U*(1-exp(f))+exp(f)));'], 'independent', 'x', 'dependent', 'y' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' ,'MaxIter',40);
opts.Display = 'Off';
opts.Lower = [lb(3:4),lb(2),lb(1)];%[0 0 0 0];
opts.StartPoint = [F0, D0,U0,f0]; %[0.855027860168076 0.806963747508719 0.156395362862094 0.133170887149803];
opts.Upper = [ub(3:4),ub(2),ub(1)];%[2 2 1 1];
[fitresult, gof] = fit( xData, yData, ft, opts );

