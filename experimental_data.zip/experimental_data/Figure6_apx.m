close all
F_DBS=[20, 50, 100 , 200]
dt=1e-4;%10 msec
T=.5; % sec
t_syn=.003;
t=(0:dt:.1);
h=exp(-t/t_syn);
figure; plot(t,h)
%%

for i=1:length(F_DBS)
    tt=dt:dt:T+.1;
    I_ref=zeros(1,T/dt);
    I_steady=I_ref;
    I_MSE=I_ref;
    I_dual=I_ref;
    pulse_num=T*F_DBS(i);
    I_ref(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(    .65,.45,.2,.75,.0000001,F_DBS(i),pulse_num);
    I_steady(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters( .78,.45,.35,.64,.0000001,F_DBS(i),pulse_num);
    I_MSE(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(    .63,.45,.2,.73,.0000001,F_DBS(i),pulse_num);
    I_dual(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(   .65,.45,.2,.75,.0000001,F_DBS(i),pulse_num);
    I_ref=conv(I_ref,h);
    I_steady=conv(I_steady,h);
    I_MSE=conv(I_MSE,h);
    I_dual=conv(I_dual,h);
    
    figure(3); 
    subplot(2,2,i)
    hold on
    plot(tt,I_ref)
    plot(tt,I_steady)
    plot(tt,I_MSE)
    plot(tt,I_dual)
    title(num2str(F_DBS(i)))
    switch i
        case 1
            xlim([0 .3])
        case 2
            xlim([0 .1])
        case 3
            xlim([0 .05])
        case 4
            xlim([0 .025])
    end
    ylim([-.1 1])
    if i==2
        legend('True','Steady-state','LMSE','Dual')
        
    end
    
    figure(4)
    subplot(2,2,i)
    hold on
    plot(DBS_profile_neurotransmitters(    .65,.45,.2,.75,.0000001,F_DBS(i),pulse_num));
    plot(DBS_profile_neurotransmitters( .78,.45,.35,.64,.0000001,F_DBS(i),pulse_num));
    plot(DBS_profile_neurotransmitters(    .63,.45,.2,.73,.0000001,F_DBS(i),pulse_num));
    plot(DBS_profile_neurotransmitters(   .65,.45,.2,.75,.0000001,F_DBS(i),pulse_num));
    
end

%%
figure(5,'Name','4 param'); 
for i=1:length(F_DBS)
    tt=dt:dt:T+.1;
    I_ref=zeros(1,T/dt);
    I_steady=I_ref;
    I_MSE=I_ref;
    I_dual=I_ref;
    pulse_num=T*F_DBS(i);
    I_ref(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(.15,.45,.1,.75,.0000001,F_DBS(i),pulse_num);
    I_steady(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(.04,.52,.5,.68,.0000001,F_DBS(i),pulse_num);
    I_MSE(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(.12,.47,.1,.73,.0000001,F_DBS(i),pulse_num);
    I_dual(1:1/(dt*F_DBS(i)):T/dt)=DBS_profile_neurotransmitters(.17,.45,.09,.75,.0000001,F_DBS(i),pulse_num);
    I_ref=conv(I_ref,h);
    I_steady=conv(I_steady,h);
    I_MSE=conv(I_MSE,h);
    I_dual=conv(I_dual,h);

    subplot(2,2,i)
    hold on
    plot(tt,I_ref)
    plot(tt,I_steady)
    plot(tt,I_MSE)
    plot(tt,I_dual)
    title(num2str(F_DBS(i)))
    axis([0 .1 -.1 .6])
    if i==2
        legend('True','Steady-state','LMSE','Dual')
    end
end
