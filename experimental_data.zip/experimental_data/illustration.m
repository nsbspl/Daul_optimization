clear 
% addpath ./Single Pulse AP Variance _ with Gabazine _ Prim�rdaten

[D si]=abfload('SP_GBZ_12.5.2016_2_na_500_ch5.abf');
[h w d]=size(D);
x=reshape(D,[h d]);

figure
plot(x)

%%
figure
t=40500:43000;
for i=1:d
    plot3(t,i+0*[t],x(t,i));
    hold on
end