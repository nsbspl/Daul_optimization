clear 
close all

load IPSCs.mat
addpath '..\'
addpath '..\..\Dual Optimizations'
addpath '..\'

T_syn=2.5/1000;
trials=1:10;
instant_response=mean([peak_IPSC_10_ch3(1,trials),peak_IPSC_20_ch3(1,trials),peak_IPSC_130_ch3(1,trials)]);
transient_steadystate_dial=10;
options = optimset('MaxFunEvals',40);

steady_state10=.8*mean(mean(peak_IPSC_10_ch3(08:end,trials)))/instant_response;
steady_state20=mean(mean(peak_IPSC_20_ch3(15:end,trials)))/instant_response;
steady_state130_1=mean(quantile(peak_IPSC_130_ch3(20:40,trials),.99))/instant_response;%mean(max(peak_IPSC_130_ch3(20:40,trials)))/instant_response;
steady_state130_2=mean(quantile(peak_IPSC_130_ch3(20:50,trials),.99))/instant_response;
F_DBS_=[10, 20 , 129,130];
I_inf=[steady_state10,steady_state20,steady_state130_1,steady_state130_2];
figure; plot(F_DBS_,I_inf,'-*')


I_REF{1}=mean(peak_IPSC_10_ch3(1:10,trials),2)/instant_response;
I_REF{2}=mean(peak_IPSC_20_ch3(1:10,trials),2)/instant_response;
I_REF{3}=mean(peak_IPSC_130_ch3(1:40,trials),2)/instant_response;
I_REF{4}=mean(peak_IPSC_130_ch3(1:60,trials),2)/instant_response;

% figure; hold on
% for i=1:3
%     plot(I_REF{i})
% end


ub4=[-3      1       1     1];% [f,U,F,D]
lb4=[-10    .0001     .0001       .0001];

ub=ub4([1,3,4]); % [f,F,D]
lb=lb4([1,3,4]);
f20=figure(20);
set(f20,'Position',[20 200 560 420])
f21=figure(21);
set(f21,'Position',[600 200 560 420])
  

for k=1:11
    RNG=rng;
    RNG.seed=k;
    X0=.99*rand(1,4).*(ub4-lb4)+lb4;
    f_dual=X0(1);
    U_dual=X0(2);
    F_dual=X0(3);
    D_dual=X0(4);
    for i=1:10
%         x0=[f_dual(i),U_dual(i),F_dual(i),D_dual(i)];
%         [fitresult, gof] = gradient_fit_experimental_4params(F_DBS_, I_inf,x0, ub4 ,lb4,T_syn);
%         U_std(i)=fitresult.U;
        
        x0=[f_dual(i),F_dual(i),D_dual(i)];
        [fitresult, gof] = gradient_fit_experimental(F_DBS_, I_inf,x0, ub ,lb,U_dual(i),T_syn);
        U_std(i)=U_dual(i);

        f_std(i)=fitresult.f;
        F_std(i)=fitresult.F;
        D_std(i)=fitresult.D;
%         figure(20)
%         subplot(3,1,1);plot(DBS_profile_neurotransmitters(f_std(i),U_dual(i),F_std(i),D_std(i),T_syn,10,10)/(U_dual(i)+f_std(i)*(1-U_dual(i)))); hold on;
%         subplot(3,1,2);plot(DBS_profile_neurotransmitters(f_std(i),U_dual(i),F_std(i),D_std(i),T_syn,20,20)/(U_dual(i)+f_std(i)*(1-U_dual(i))),'k');hold on;
%         subplot(3,1,3);plot(DBS_profile_neurotransmitters(f_std(i),U_dual(i),F_std(i),D_std(i),T_syn,130,130)/(U_dual(i)+f_std(i)*(1-U_dual(i))),'k');hold on;

        x_std=[f_std(i),U_std(i),F_std(i),D_std(i)];

        fun = @(x)100*Profile_Error(x,I_REF,T_syn,F_DBS_); % assigning the errro function
        func= @(x)fine_tune_error(fun,x,x_std,transient_steadystate_dial);

        [x,fval]=fminsearchbnd(func,x_std,lb4,ub4,options);

        f_dual(i+1)=x(1);
        U_dual(i+1)=x(2);
        F_dual(i+1)=x(3);
        D_dual(i+1)=x(4);
%         figure(21)
%         subplot(3,1,1);plot(DBS_profile_neurotransmitters(f_dual(i+1),U_dual(i+1),F_dual(i+1),D_dual(i+1),T_syn,10,10)/(U_dual(i+1)+f_dual(i+1)*(1-U_dual(i+1)))); hold on;
%         subplot(3,1,2);plot(DBS_profile_neurotransmitters(f_dual(i+1),U_dual(i+1),F_dual(i+1),D_dual(i+1),T_syn,20,20)/(U_dual(i+1)+f_dual(i+1)*(1-U_dual(i+1))),'k');hold on;
%         subplot(3,1,3);plot(DBS_profile_neurotransmitters(f_dual(i+1),U_dual(i+1),F_dual(i+1),D_dual(i+1),T_syn,130,130)/(U_dual(i+1)+f_dual(i+1)*(1-U_dual(i+1))),'k');hold on;
    end
    f_(k)=mean(f_dual(10:end));
    U_(k)=mean(U_dual(10:end));
    F_(k)=mean(F_dual(10:end));
    D_(k)=mean(D_dual(10:end));
    
    f__(k)=mean(f_std(10:end))
    U__(k)=mean(U_std(10:end))
    F__(k)=mean(F_std(10:end))
    D__(k)=mean(D_std(10:end))
end
figure(20);title('Steady-state')
subplot(3,1,1); plot(mean(peak_IPSC_10_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,2); plot(mean(peak_IPSC_20_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,3); plot(mean(peak_IPSC_130_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);

figure(21);title('Dual')
subplot(3,1,1); plot(mean(peak_IPSC_10_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,2); plot(mean(peak_IPSC_20_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,3); plot(mean(peak_IPSC_130_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);

%%

x0=[f_dual(i),F_dual(i),D_dual(i)];
[fitresult, gof] = gradient_fit_experimental(F_DBS_, I_inf,x0, ub ,lb,U_dual(i),T_syn);
f_std(i)=fitresult.f;
F_std(i)=fitresult.F;
D_std(i)=fitresult.D;
figure(24)
subplot(3,1,1);plot(DBS_profile_neurotransmitters(exp(f_std(i)),U_dual(i),F_std(i),D_std(i),5,10,10)/(U_dual(i)+f_std(i)*(1-U_dual(i)))); hold on;
subplot(3,1,2);plot(DBS_profile_neurotransmitters(exp(f_std(i)),U_dual(i),F_std(i),D_std(i),5,20,20)/(U_dual(i)+f_std(i)*(1-U_dual(i))),'k');hold on;
subplot(3,1,3);plot(DBS_profile_neurotransmitters(exp(f_std(i)),U_dual(i),F_std(i),D_std(i),5,130,130)/(U_dual(i)+f_std(i)*(1-U_dual(i))),'k');hold on;

x_std=[f_std(i),U_dual(i),F_std(i),D_std(i)];

fun = @(x)100*Profile_Error(x,I_REF,T_syn,F_DBS_); % assigning the errro function
func= @(x)fine_tune_error(fun,x,x_std,1);

[x,fval]=fminsearchbnd(func,x_std,lb4,ub4,options);

f_dual(i+1)=x(1);
U_dual(i+1)=x(2);
F_dual(i+1)=x(3);
D_dual(i+1)=x(4);
figure(25)
subplot(3,1,1);plot(DBS_profile_neurotransmitters(exp(f_dual(i+1)),U_dual(i+1),F_dual(i+1),D_dual(i+1),5,10,10)/(U_dual(i+1)+f_dual(i+1)*(1-U_dual(i+1)))); hold on;
subplot(3,1,2);plot(DBS_profile_neurotransmitters(exp(f_dual(i+1)),U_dual(i+1),F_dual(i+1),D_dual(i+1),5,20,20)/(U_dual(i+1)+f_dual(i+1)*(1-U_dual(i+1))),'k');hold on;
subplot(3,1,3);plot(DBS_profile_neurotransmitters(exp(f_dual(i+1)),U_dual(i+1),F_dual(i+1),D_dual(i+1),5,130,130)/(U_dual(i+1)+f_dual(i+1)*(1-U_dual(i+1))),'k');hold on;



figure(24);title('Steady-state')
subplot(3,1,1); plot(mean(peak_IPSC_10_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,2); plot(mean(peak_IPSC_20_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,3); plot(mean(peak_IPSC_130_ch3')/instant_response,'r','LineWidth',2); ylim([0 1]);

figure(25);title('Dual')
subplot(3,1,1); plot((peak_IPSC_10_ch3(:,trials))/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,2); plot((peak_IPSC_20_ch3(:,trials))/instant_response,'r','LineWidth',2); ylim([0 1]);
subplot(3,1,3); plot((peak_IPSC_130_ch3(:,trials))/instant_response,'r','LineWidth',2); ylim([0 1]);

%%
figure(1); histogram(f_std,'BinWidth',.001,'FaceColor','b'); title('f_{std}')
figure(2); histogram(F_std,'BinWidth',.001,'FaceColor','b'); title('F_{std}')
figure(3); histogram(D_std,'BinWidth',.001,'FaceColor','b'); title('D_{std}')

figure(1); hold on; histogram(f_dual,'BinWidth',.001,'FaceColor','r'); title('f_{Dual}')
figure(2); hold on; histogram(F_dual,'BinWidth',.001,'FaceColor','r'); title('F_{Dual}')
figure(3); hold on; histogram(D_dual,'BinWidth',.001,'FaceColor','r'); title('D_{Dual}')
%%
figure7X;

fig=figure(10); set(fig,'position',[100 100 1000 400]);
fig=figure(20); set(fig,'position',[100 100 1000 400]);
fig=figure(130); set(fig,'position',[100 100 1000 400]);

%%
x_values=linspace(0,.02,1000);
hold on

pd = fitdist(exp(f_'),'Kernel','Kernel','normal');
y = pdf(pd,x_values);
y_dual=y./max(y);
 
pd = fitdist(exp(f__'),'Kernel','Kernel','normal');
y = pdf(pd,x_values);
y_std=y./max(y);

figure
s=subplot(1,1,1);
hold on
area(x_values,y_dual,'FaceColor','b','EdgeColor','b','FaceAlpha',0.5)
set(s,'YTick',[0,1],'FontSize',20)
title('f')
% legend('Steady state','Dual','CORRECT','Location','northeast');
%%

x_values=linspace(0,0.05,1000);
hold on

pd = fitdist((F_'),'Kernel','Kernel','normal');
y = pdf(pd,x_values);
y_dual=y./max(y);
 
% pd = fitdist((F__'),'Kernel','Kernel','normal');
% y = pdf(pd,x_values);
% y_std=y./max(y);

figure
s=subplot(1,1,1);
hold on
area(x_values,y_dual,'FaceColor','b','EdgeColor','b','FaceAlpha',0.5)
title('F')
set(s,'YTick',[0,1],'FontSize',20)

%%
x_values=linspace(0,1,1000);
hold on

pd = fitdist((D_'),'Kernel','Kernel','normal');
y = pdf(pd,x_values);
y_dual=y./max(y);
 
pd = fitdist((D__'),'Kernel','Kernel','normal');
y = pdf(pd,x_values);
y_std=y./max(y);

figure
s=subplot(1,1,1);
hold on
area(x_values,y_dual,'FaceColor','b','EdgeColor','b','FaceAlpha',0.5)
title('D')
set(s,'YTick','','FontSize',20);

%%
x_values=linspace(0,.2,1000);

pd = fitdist((U_'),'Kernel','Kernel','normal');
y = pdf(pd,x_values);
y_dual=y./max(y);

figure
s=subplot(1,1,1);
hold on
area(x_values,y_dual,'FaceColor','b','EdgeColor','b','FaceAlpha',0.5)
title('U')
set(s,'YTick','','FontSize',20);